import logo from './logo.svg';
import './App.css';
import SignupForm from './components/SignupForm';
function App() {
  return (
    <div>
      <SignupForm/>
    </div>
   
  );
}

export default App;
